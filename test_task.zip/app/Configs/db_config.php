<?php

$config = [
    'mysql' => [
        'port' => 3306,
        'host' => 'localhost',
        'login' => 'root',
        'pass' => '',
        'db_name' => 'task'
    ]
];