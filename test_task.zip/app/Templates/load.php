<div class="mb-3">
    <form method="post" enctype="multipart/form-data">
        <label for="formFile" class="form-label">Выберите файл (csv)</label>
        <input class="form-control" type="file" name="user_file" id="formFile">
        <input class="btn btn-primary mt-4" type="submit" value="Импортировать">
    </form>
</div>